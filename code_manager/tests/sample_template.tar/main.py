from diamant_game_interface import PlayerInterface
import random


def handle_decision(game_state: dict):  # entrypoint for all game decisions
    print(game_state)
    return random.randint(0, 1)


if __name__ == "__main__":
    """
    Provide any callable as an argument to PlayerInterface. Each time the bot
    gets to make a decision, the callable will be called with a single
    parameter (a dictionary) containing all the information relevant to the
    state of the game. Using this data, the bot will have to return True or
    False indicating whether or not they wish to keep going.
    
    A sample function `handle_decision` is provided for illustration purposes.
    """
    game = PlayerInterface(handle_decision)

    # do some more setup if needed

    game.start()
